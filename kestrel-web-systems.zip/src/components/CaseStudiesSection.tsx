import { useEffect, useState } from 'react';
import { ArrowUpRight, X } from 'lucide-react';
import { CASE_STUDIES, type CaseStudy } from '../data/studioData';
import { ResilientImage } from './ResilientImage';

interface CaseStudiesSectionProps {
  onRequestSimilar: (projectTitle: string) => void;
}

export function CaseStudiesSection({
  onRequestSimilar,
}: CaseStudiesSectionProps) {
  const [selectedStudy, setSelectedStudy] = useState<CaseStudy | null>(null);

  useEffect(() => {
    if (!selectedStudy) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setSelectedStudy(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedStudy]);

  return (
    <section
      id="case-studies"
      className="py-16 sm:py-24 border-b border-zinc-200 bg-white"
    >
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mb-12">
          <p className="text-xs font-medium text-zinc-500 mb-2">
            Verified Outcomes
          </p>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-zinc-900">
            Production React interfaces measured by load speed and completion.
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {CASE_STUDIES.map((study) => (
            <article
              key={study.id}
              className="flex flex-col justify-between bg-[#FAFAFA] border border-zinc-200 rounded-xl overflow-hidden"
            >
              <div>
                <div className="aspect-[4/3] w-full overflow-hidden border-b border-zinc-200 bg-zinc-100">
                  <ResilientImage
                    src={study.image}
                    alt={study.imageAlt}
                    fallbackTitle={study.title}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="p-6">
                  <div className="text-xs text-zinc-500 mb-2">
                    <span>{study.sector}</span>
                    <span aria-hidden="true"> · </span>
                    <span>{study.stack}</span>
                    <span aria-hidden="true"> · </span>
                    <span>{study.timeline}</span>
                  </div>

                  <h3 className="text-lg font-semibold tracking-tight text-zinc-900 leading-snug">
                    {study.title}
                  </h3>

                  <div className="mt-3 text-xs font-mono font-semibold text-[#1E40AF] tabular-nums">
                    {study.impactMetric}
                  </div>

                  <p className="mt-3 text-sm text-zinc-600 leading-relaxed">
                    {study.summary}
                  </p>
                </div>
              </div>

              <div className="px-6 pb-6 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedStudy(study)}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-zinc-900 hover:text-[#1E40AF] transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1E40AF] rounded-sm"
                >
                  <span>Read Architecture Brief</span>
                  <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>

      {/* Case Study Architecture Brief Modal */}
      {selectedStudy && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="case-study-dialog-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/50 backdrop-blur-[2px]"
          onClick={() => setSelectedStudy(null)}
        >
          <div
            className="w-full max-w-2xl bg-white border border-zinc-200 rounded-xl overflow-hidden shadow-xl max-h-[90vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4 p-6 border-b border-zinc-200">
              <div>
                <div className="text-xs text-zinc-500 mb-1">
                  {selectedStudy.sector} · {selectedStudy.stack} ·{' '}
                  {selectedStudy.timeline}
                </div>
                <h3
                  id="case-study-dialog-title"
                  className="text-xl font-bold tracking-tight text-zinc-900"
                >
                  {selectedStudy.title}
                </h3>
              </div>

              <button
                type="button"
                onClick={() => setSelectedStudy(null)}
                aria-label="Close architecture brief"
                className="w-9 h-9 inline-flex items-center justify-center rounded-lg border border-zinc-200 text-zinc-600 hover:text-zinc-900 hover:bg-zinc-50 cursor-pointer shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1E40AF]"
              >
                <X className="w-4 h-4" aria-hidden="true" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-6 text-sm">
              <div>
                <h4 className="text-xs font-semibold text-zinc-500 mb-1.5">
                  Engineering Bottleneck
                </h4>
                <p className="text-zinc-700 leading-relaxed">
                  {selectedStudy.challenge}
                </p>
              </div>

              <div>
                <h4 className="text-xs font-semibold text-zinc-500 mb-1.5">
                  React Front-End Architecture
                </h4>
                <p className="text-zinc-700 leading-relaxed">
                  {selectedStudy.architecture}
                </p>
              </div>

              <div>
                <h4 className="text-xs font-semibold text-zinc-500 mb-2">
                  Measured Production Impact
                </h4>
                <ul className="space-y-2 border-t border-zinc-200 pt-3">
                  {selectedStudy.results.map((item) => (
                    <li
                      key={item}
                      className="text-zinc-900 font-medium font-mono text-xs tabular-nums"
                    >
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="p-6 border-t border-zinc-200 bg-[#FAFAFA] flex flex-wrap items-center justify-between gap-4">
              <button
                type="button"
                onClick={() => setSelectedStudy(null)}
                className="px-4 py-2 text-xs font-semibold text-zinc-700 hover:text-zinc-900 cursor-pointer"
              >
                Close Brief
              </button>
              <button
                type="button"
                onClick={() => {
                  const title = selectedStudy.title;
                  setSelectedStudy(null);
                  onRequestSimilar(title);
                }}
                className="px-4 py-2 text-xs font-semibold text-white bg-[#1E40AF] hover:bg-[#1E3A8A] rounded-lg transition-colors cursor-pointer whitespace-nowrap"
              >
                Discuss Similar Architecture
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
