import { CAPABILITIES } from '../data/studioData';

export function CapabilitiesSection() {
  return (
    <section id="capabilities" className="py-16 sm:py-24 border-b border-zinc-200">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mb-12">
          <p className="text-xs font-medium text-zinc-500 mb-2">
            Engineering Capabilities
          </p>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-zinc-900">
            Front-end systems designed for long-term product velocity.
          </h2>
        </div>

        {/* Asymmetric bento grid (col-span-2 alongside col-span-1) */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {CAPABILITIES.map((cap) => (
            <article
              key={cap.index}
              className={`bg-white border border-zinc-200 rounded-xl p-6 sm:p-8 flex flex-col justify-between ${
                cap.span === 'wide' ? 'lg:col-span-2' : 'lg:col-span-1'
              }`}
            >
              <div>
                <div className="font-mono text-xs font-medium text-zinc-500 mb-3">
                  {cap.index}
                </div>
                <h3 className="text-lg sm:text-xl font-semibold tracking-tight text-zinc-900">
                  {cap.title}
                </h3>
                <p className="mt-3 text-sm sm:text-base text-zinc-600 leading-relaxed max-w-2xl">
                  {cap.summary}
                </p>
              </div>

              <div className="mt-8 pt-4 border-t border-zinc-100 text-xs font-medium text-zinc-700">
                Outcome: {cap.outcome}
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
