import { useEffect, useState, type FormEvent, type RefObject } from 'react';
import { CheckCircle2 } from 'lucide-react';

interface InquirySectionProps {
  nameInputRef: RefObject<HTMLInputElement | null>;
  prefilledTopic: string;
}

interface FormErrors {
  fullName?: string;
  email?: string;
  brief?: string;
}

const SCOPE_OPTIONS = [
  'New React Web Application',
  'Design System & Component Library',
  'Performance & Bundle Audit',
  'Legacy Front-End Migration',
];

export function InquirySection({
  nameInputRef,
  prefilledTopic,
}: InquirySectionProps) {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [scope, setScope] = useState(SCOPE_OPTIONS[0]);
  const [brief, setBrief] = useState('');
  const [errors, setErrors] = useState<FormErrors>({});
  const [submittedRecord, setSubmittedRecord] = useState<{
    fullName: string;
    email: string;
    scope: string;
  } | null>(null);

  useEffect(() => {
    if (prefilledTopic) {
      setBrief(
        `Interested in an architecture review modeled on "${prefilledTopic}".`
      );
    }
  }, [prefilledTopic]);

  const validate = (): FormErrors => {
    const nextErrors: FormErrors = {};
    if (fullName.trim().length < 2) {
      nextErrors.fullName = 'Please enter your full name.';
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      nextErrors.email = 'Please enter a valid work email address.';
    }
    if (brief.trim().length < 20) {
      nextErrors.brief =
        'Please share at least 20 characters about your React stack or goals.';
    }
    return nextErrors;
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setErrors({});
    setSubmittedRecord({
      fullName: fullName.trim(),
      email: email.trim(),
      scope,
    });
  };

  const handleReset = () => {
    setSubmittedRecord(null);
    setFullName('');
    setEmail('');
    setScope(SCOPE_OPTIONS[0]);
    setBrief('');
    setErrors({});
  };

  return (
    <section id="inquiry" className="py-16 sm:py-24 border-b border-zinc-200">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
          <div className="lg:col-span-5 space-y-4">
            <p className="text-xs font-medium text-zinc-500">
              Technical Discovery
            </p>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-zinc-900">
              Schedule a front-end architecture review.
            </h2>
            <p className="text-sm sm:text-base text-zinc-600 leading-relaxed">
              Share your current repository structure, performance bottlenecks, or upcoming React roadmap. A principal front-end engineer responds within one business day with a concrete scope.
            </p>

            <div className="pt-4 border-t border-zinc-200 space-y-2 text-xs text-zinc-600">
              <div>Typical Engagement: 4 to 12 week delivery sprints</div>
              <div>Deliverables: Production TypeScript PRs, component docs, and audit benchmarks</div>
            </div>
          </div>

          <div className="lg:col-span-7 bg-white border border-zinc-200 rounded-xl p-6 sm:p-8">
            {submittedRecord ? (
              <div className="py-6 space-y-4">
                <div className="inline-flex items-center gap-2 text-emerald-800 font-semibold text-sm">
                  <CheckCircle2 className="w-5 h-5" aria-hidden="true" />
                  <span>Architecture review request recorded</span>
                </div>
                <p className="text-sm text-zinc-600 leading-relaxed">
                  Thank you, <strong className="text-zinc-900">{submittedRecord.fullName}</strong>. We have logged your brief for{' '}
                  <strong className="text-zinc-900">{submittedRecord.scope}</strong> and prepared a confirmation copy for{' '}
                  <span className="font-mono text-zinc-800">{submittedRecord.email}</span>.
                </p>
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={handleReset}
                    className="px-4 py-2 text-xs font-semibold text-zinc-800 bg-zinc-100 hover:bg-zinc-200 rounded-lg transition-colors cursor-pointer"
                  >
                    Submit Another Request
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label
                      htmlFor="inquiry-full-name"
                      className="block text-xs font-semibold text-zinc-800 mb-1.5"
                    >
                      Full Name
                    </label>
                    <input
                      ref={nameInputRef}
                      id="inquiry-full-name"
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      aria-invalid={Boolean(errors.fullName)}
                      aria-describedby={
                        errors.fullName ? 'inquiry-full-name-error' : undefined
                      }
                      placeholder="Clara Lindqvist"
                      className={`w-full px-3.5 py-2.5 text-sm bg-white border rounded-lg text-zinc-900 placeholder:text-zinc-400 focus-visible:outline-none focus-visible:ring-2 ${
                        errors.fullName
                          ? 'border-red-600 focus-visible:ring-red-600'
                          : 'border-zinc-300 focus-visible:ring-[#1E40AF]'
                      }`}
                    />
                    {errors.fullName && (
                      <p
                        id="inquiry-full-name-error"
                        className="mt-1.5 text-xs text-red-700 font-medium"
                      >
                        {errors.fullName}
                      </p>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="inquiry-email"
                      className="block text-xs font-semibold text-zinc-800 mb-1.5"
                    >
                      Work Email
                    </label>
                    <input
                      id="inquiry-email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      aria-invalid={Boolean(errors.email)}
                      aria-describedby={
                        errors.email ? 'inquiry-email-error' : undefined
                      }
                      placeholder="clara@company.com"
                      className={`w-full px-3.5 py-2.5 text-sm bg-white border rounded-lg text-zinc-900 placeholder:text-zinc-400 focus-visible:outline-none focus-visible:ring-2 ${
                        errors.email
                          ? 'border-red-600 focus-visible:ring-red-600'
                          : 'border-zinc-300 focus-visible:ring-[#1E40AF]'
                      }`}
                    />
                    {errors.email && (
                      <p
                        id="inquiry-email-error"
                        className="mt-1.5 text-xs text-red-700 font-medium"
                      >
                        {errors.email}
                      </p>
                    )}
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="inquiry-scope"
                    className="block text-xs font-semibold text-zinc-800 mb-1.5"
                  >
                    Engagement Scope
                  </label>
                  <select
                    id="inquiry-scope"
                    value={scope}
                    onChange={(e) => setScope(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-zinc-300 rounded-lg text-zinc-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1E40AF]"
                  >
                    {SCOPE_OPTIONS.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="inquiry-brief"
                    className="block text-xs font-semibold text-zinc-800 mb-1.5"
                  >
                    Project Context &amp; Technical Goals
                  </label>
                  <textarea
                    id="inquiry-brief"
                    rows={4}
                    value={brief}
                    onChange={(e) => setBrief(e.target.value)}
                    aria-invalid={Boolean(errors.brief)}
                    aria-describedby={
                      errors.brief ? 'inquiry-brief-error' : undefined
                    }
                    placeholder="Outline your React version, target milestones, and any UI or bundle performance constraints..."
                    className={`w-full px-3.5 py-2.5 text-sm bg-white border rounded-lg text-zinc-900 placeholder:text-zinc-400 focus-visible:outline-none focus-visible:ring-2 ${
                      errors.brief
                        ? 'border-red-600 focus-visible:ring-red-600'
                        : 'border-zinc-300 focus-visible:ring-[#1E40AF]'
                    }`}
                  />
                  {errors.brief && (
                    <p
                      id="inquiry-brief-error"
                      className="mt-1.5 text-xs text-red-700 font-medium"
                    >
                      {errors.brief}
                    </p>
                  )}
                </div>

                <div className="pt-1 flex items-center justify-between gap-4">
                  <span className="text-xs text-zinc-500">
                    NDA available prior to repository access.
                  </span>
                  <button
                    type="submit"
                    className="px-5 py-2.5 text-sm font-semibold text-white bg-[#1E40AF] hover:bg-[#1E3A8A] rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1E40AF] focus-visible:ring-offset-2"
                  >
                    Request Architecture Review
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
