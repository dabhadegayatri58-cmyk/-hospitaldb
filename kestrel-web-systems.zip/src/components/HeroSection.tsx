import { ArrowRight } from 'lucide-react';
import { HERO_MEDIA, HERO_METRICS } from '../data/studioData';
import { ResilientImage } from './ResilientImage';

interface HeroSectionProps {
  onPrimaryCta: () => void;
}

export function HeroSection({ onPrimaryCta }: HeroSectionProps) {
  return (
    <section className="pt-12 pb-16 sm:pt-16 sm:pb-20 border-b border-zinc-200">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Two-column balanced hero split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
          <div className="lg:col-span-6 flex flex-col justify-between py-1">
            <div>
              <p className="text-xs font-medium text-zinc-500 mb-5">
                Zurich &amp; San Francisco <span aria-hidden="true">·</span> React 19 &amp; TypeScript Engineering
              </p>

              <h1
                className="font-bold tracking-tight text-zinc-900 leading-[1.08] max-w-xl"
                style={{ fontSize: 'clamp(2.25rem, 4vw, 3.5rem)' }}
              >
                React web front ends built for speed, clarity, and scale.
              </h1>

              <p className="mt-6 text-base sm:text-lg text-zinc-600 leading-relaxed max-w-xl">
                We architect and ship production React applications, accessible component systems, and sub-second interactive interfaces for engineering-led product teams.
              </p>
            </div>

            <div className="mt-8 pt-2 flex flex-wrap items-center gap-6">
              <button
                type="button"
                onClick={onPrimaryCta}
                className="inline-flex items-center gap-2 px-5 py-3 text-sm font-semibold text-white bg-[#1E40AF] hover:bg-[#1E3A8A] rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1E40AF] focus-visible:ring-offset-2"
              >
                <span>Book Architecture Review</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </button>

              <a
                href="#workbench"
                className="text-sm font-semibold text-zinc-800 hover:text-[#1E40AF] underline underline-offset-4 transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1E40AF] rounded-sm"
              >
                Open Live Workbench
              </a>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="aspect-video lg:aspect-auto lg:h-full w-full overflow-hidden rounded-xl border border-zinc-200 bg-zinc-100">
              <ResilientImage
                src={HERO_MEDIA.src}
                alt={HERO_MEDIA.alt}
                fallbackTitle="Kestrel Engineering Studio"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>

        {/* Full-width 4-column quantified KPI strip */}
        <div className="mt-12 pt-10 border-t border-zinc-200 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {HERO_METRICS.map((metric) => (
            <div key={metric.label} className="space-y-1.5">
              <div className="text-2xl sm:text-3xl font-bold tracking-tight text-zinc-900 font-mono tabular-nums">
                {metric.value}
              </div>
              <div className="text-sm font-semibold text-zinc-900">
                {metric.label}
              </div>
              <div className="text-xs text-zinc-500 leading-relaxed">
                {metric.context}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
