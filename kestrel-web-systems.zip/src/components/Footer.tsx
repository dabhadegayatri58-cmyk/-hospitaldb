export function Footer() {
  return (
    <footer className="py-10 bg-[#FAFAFA]">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="text-base font-bold tracking-tight text-zinc-900">
            Kestrel
          </div>
          <p className="text-xs text-zinc-500">
            React Web Front-End Engineering · Zurich &amp; San Francisco
          </p>
        </div>

        <nav
          aria-label="Footer"
          className="flex flex-wrap items-center gap-6 text-xs font-medium text-zinc-600"
        >
          <a href="#capabilities" className="hover:text-zinc-900 transition-colors">
            Capabilities
          </a>
          <a href="#workbench" className="hover:text-zinc-900 transition-colors">
            Workbench
          </a>
          <a href="#case-studies" className="hover:text-zinc-900 transition-colors">
            Case Studies
          </a>
          <a href="#inquiry" className="hover:text-zinc-900 transition-colors">
            Architecture Review
          </a>
          <a
            href="mailto:hello@kestrelfrontend.dev"
            className="text-zinc-800 hover:text-[#1E40AF] transition-colors"
          >
            hello@kestrelfrontend.dev
          </a>
        </nav>

        <div className="text-xs text-zinc-500">
          &copy; 2026 Kestrel Web Systems
        </div>
      </div>
    </footer>
  );
}
