import { useMemo, useState } from 'react';
import {
  ArrowUpDown,
  Check,
  ChevronDown,
  RotateCcw,
  Search,
} from 'lucide-react';
import { MODULE_AUDIT_ROWS, type ModuleAuditRow } from '../data/studioData';

type WorkbenchTab = 'tokens' | 'audit' | 'motion';
type AccentPreset = 'cobalt' | 'forest' | 'graphite';
type RadiusPreset = '4px' | '8px' | '12px';
type DensityPreset = 'compact' | 'balanced' | 'airy';
type CategoryFilter = 'All' | 'Core' | 'State' | 'UI';
type SortField = 'gzipKb' | 'parseMs';
type SortDirection = 'asc' | 'desc';

const ACCENT_MAP: Record<
  AccentPreset,
  { name: string; hex: string; contrast: string; grade: string }
> = {
  cobalt: {
    name: 'Cobalt',
    hex: '#1E40AF',
    contrast: '8.72 : 1',
    grade: 'WCAG AAA',
  },
  forest: {
    name: 'Forest',
    hex: '#15803D',
    contrast: '5.14 : 1',
    grade: 'WCAG AA',
  },
  graphite: {
    name: 'Graphite',
    hex: '#18181B',
    contrast: '17.40 : 1',
    grade: 'WCAG AAA',
  },
};

const CURVE_OPTIONS = [
  {
    id: 'crisp',
    label: 'Crisp Ease Out',
    css: 'cubic-bezier(0.16, 1, 0.3, 1)',
    description: 'Fast initial response with a quiet, zero-overshoot settle.',
  },
  {
    id: 'editorial',
    label: 'Editorial Settle',
    css: 'cubic-bezier(0.22, 1, 0.36, 1)',
    description: 'Measured deceleration suited to drawers and detail panes.',
  },
  {
    id: 'linear-snap',
    label: 'Snappy Standard',
    css: 'cubic-bezier(0.2, 0, 0, 1)',
    description: 'High-intent state toggle curve for dense enterprise controls.',
  },
];

export function InteractiveWorkbench() {
  const [activeTab, setActiveTab] = useState<WorkbenchTab>('tokens');

  // Tab 1: Token & Accessibility Lab state
  const [accent, setAccent] = useState<AccentPreset>('cobalt');
  const [radius, setRadius] = useState<RadiusPreset>('8px');
  const [density, setDensity] = useState<DensityPreset>('balanced');
  const [previewScope, setPreviewScope] = useState<'all' | 'active'>('all');
  const [disclosureOpen, setDisclosureOpen] = useState(false);
  const [sampleEmail, setSampleEmail] = useState('engineering@acme.io');

  const isSampleEmailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
    sampleEmail.trim()
  );

  // Tab 2: Bundle & Runtime Audit Grid state
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<CategoryFilter>('All');
  const [sortField, setSortField] = useState<SortField>('gzipKb');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');

  const filteredModules = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return MODULE_AUDIT_ROWS.filter((row) => {
      const matchesCategory =
        categoryFilter === 'All' || row.category === categoryFilter;
      const matchesQuery =
        !q ||
        row.moduleName.toLowerCase().includes(q) ||
        row.category.toLowerCase().includes(q);
      return matchesCategory && matchesQuery;
    }).sort((a, b) => {
      const diff = a[sortField] - b[sortField];
      return sortDirection === 'asc' ? diff : -diff;
    });
  }, [searchQuery, categoryFilter, sortField, sortDirection]);

  const totalBundleKb = useMemo(
    () =>
      filteredModules.reduce((sum, item) => sum + item.gzipKb, 0).toFixed(1),
    [filteredModules]
  );

  const handleSortToggle = (field: SortField) => {
    if (sortField === field) {
      setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const resetAuditFilters = () => {
    setSearchQuery('');
    setCategoryFilter('All');
    setSortField('gzipKb');
    setSortDirection('desc');
  };

  // Tab 3: Motion & Settling Lab state
  const [selectedCurveId, setSelectedCurveId] = useState(CURVE_OPTIONS[0].id);
  const [durationMs, setDurationMs] = useState(180);
  const [panelShifted, setPanelShifted] = useState(false);

  const selectedCurve =
    CURVE_OPTIONS.find((c) => c.id === selectedCurveId) ?? CURVE_OPTIONS[0];
  const selectedAccent = ACCENT_MAP[accent];

  const previewPaddingClass =
    density === 'compact'
      ? 'p-4 gap-3'
      : density === 'balanced'
        ? 'p-6 gap-5'
        : 'p-8 gap-6';

  return (
    <section
      id="workbench"
      className="py-16 sm:py-24 border-b border-zinc-200 bg-white"
    >
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-10">
          <div className="max-w-2xl">
            <p className="text-xs font-medium text-zinc-500 mb-2">
              Interactive Front-End Workbench
            </p>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-zinc-900">
              Inspect how our React primitives behave under real state.
            </h2>
          </div>

          {/* Segmented Workbench Mode Controls */}
          <div
            role="tablist"
            aria-label="Workbench modes"
            className="inline-flex flex-wrap items-center gap-1 p-1 bg-zinc-100 rounded-lg border border-zinc-200 self-start"
          >
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === 'tokens'}
              onClick={() => setActiveTab('tokens')}
              className={`px-3.5 py-2 text-xs font-semibold rounded-md transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1E40AF] ${
                activeTab === 'tokens'
                  ? 'bg-white text-zinc-900 shadow-xs'
                  : 'text-zinc-600 hover:text-zinc-900'
              }`}
            >
              Token &amp; Contrast Lab
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === 'audit'}
              onClick={() => setActiveTab('audit')}
              className={`px-3.5 py-2 text-xs font-semibold rounded-md transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1E40AF] ${
                activeTab === 'audit'
                  ? 'bg-white text-zinc-900 shadow-xs'
                  : 'text-zinc-600 hover:text-zinc-900'
              }`}
            >
              Bundle &amp; Runtime Grid
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === 'motion'}
              onClick={() => setActiveTab('motion')}
              className={`px-3.5 py-2 text-xs font-semibold rounded-md transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1E40AF] ${
                activeTab === 'motion'
                  ? 'bg-white text-zinc-900 shadow-xs'
                  : 'text-zinc-600 hover:text-zinc-900'
              }`}
            >
              Motion &amp; Frame Budget
            </button>
          </div>
        </div>

        {/* Tab 1: Token & Contrast Lab */}
        {activeTab === 'tokens' && (
          <div
            role="tabpanel"
            aria-label="Token and Contrast Lab"
            className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch"
          >
            {/* Left Controls */}
            <div className="lg:col-span-5 bg-[#FAFAFA] border border-zinc-200 rounded-xl p-6 space-y-6">
              <div>
                <h3 className="text-sm font-semibold text-zinc-900 mb-3">
                  Accent Token
                </h3>
                <div className="grid grid-cols-3 gap-2">
                  {(Object.keys(ACCENT_MAP) as AccentPreset[]).map((key) => {
                    const item = ACCENT_MAP[key];
                    const selected = accent === key;
                    return (
                      <button
                        key={key}
                        type="button"
                        onClick={() => setAccent(key)}
                        className={`flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium rounded-lg border transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1E40AF] ${
                          selected
                            ? 'bg-white border-zinc-900 text-zinc-900'
                            : 'bg-white/60 border-zinc-200 text-zinc-600 hover:text-zinc-900'
                        }`}
                      >
                        <span
                          aria-hidden="true"
                          className="w-3 h-3 rounded-xs shrink-0"
                          style={{ backgroundColor: item.hex }}
                        />
                        <span>{item.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <h3 className="text-sm font-semibold text-zinc-900 mb-3">
                  Control Radius
                </h3>
                <div className="grid grid-cols-3 gap-2">
                  {(['4px', '8px', '12px'] as RadiusPreset[]).map((val) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => setRadius(val)}
                      className={`px-3 py-2 text-xs font-mono font-medium rounded-lg border transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1E40AF] ${
                        radius === val
                          ? 'bg-white border-zinc-900 text-zinc-900'
                          : 'bg-white/60 border-zinc-200 text-zinc-600 hover:text-zinc-900'
                      }`}
                    >
                      {val}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-sm font-semibold text-zinc-900 mb-3">
                  Container Density
                </h3>
                <div className="grid grid-cols-3 gap-2">
                  {(
                    [
                      { id: 'compact', label: 'Compact' },
                      { id: 'balanced', label: 'Balanced' },
                      { id: 'airy', label: 'Airy' },
                    ] as const
                  ).map((d) => (
                    <button
                      key={d.id}
                      type="button"
                      onClick={() => setDensity(d.id)}
                      className={`px-3 py-2 text-xs font-medium rounded-lg border transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1E40AF] ${
                        density === d.id
                          ? 'bg-white border-zinc-900 text-zinc-900'
                          : 'bg-white/60 border-zinc-200 text-zinc-600 hover:text-zinc-900'
                      }`}
                    >
                      {d.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-zinc-200 flex items-center justify-between text-xs">
                <div>
                  <span className="text-zinc-500">Contrast on #FFFFFF</span>
                  <div className="font-mono font-semibold text-zinc-900 tabular-nums mt-0.5">
                    {selectedAccent.contrast} ({selectedAccent.grade})
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-zinc-500">Token Value</span>
                  <div className="font-mono text-zinc-900 mt-0.5">
                    {selectedAccent.hex}
                  </div>
                </div>
              </div>
            </div>

            {/* Right Live React Preview Surface */}
            <div className="lg:col-span-7 bg-[#FAFAFA] border border-zinc-200 rounded-xl p-6 flex flex-col justify-center">
              <div
                className={`bg-white border border-zinc-200 flex flex-col ${previewPaddingClass}`}
                style={{ borderRadius: radius }}
              >
                <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-zinc-200">
                  <div>
                    <h4 className="text-base font-semibold text-zinc-900">
                      Release Readiness Checklist
                    </h4>
                    <p className="text-xs text-zinc-500 mt-0.5">
                      Live component preview updating with active design tokens
                    </p>
                  </div>

                  <div className="inline-flex p-1 bg-zinc-100 rounded-lg">
                    <button
                      type="button"
                      onClick={() => setPreviewScope('all')}
                      className={`px-3 py-1 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
                        previewScope === 'all'
                          ? 'bg-white text-zinc-900 shadow-xs'
                          : 'text-zinc-600 hover:text-zinc-900'
                      }`}
                      style={{
                        borderRadius: `calc(${radius} - 2px)`,
                      }}
                    >
                      All Checks
                    </button>
                    <button
                      type="button"
                      onClick={() => setPreviewScope('active')}
                      className={`px-3 py-1 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
                        previewScope === 'active'
                          ? 'bg-white text-zinc-900 shadow-xs'
                          : 'text-zinc-600 hover:text-zinc-900'
                      }`}
                      style={{
                        borderRadius: `calc(${radius} - 2px)`,
                      }}
                    >
                      Verified Only
                    </button>
                  </div>
                </div>

                {/* Interactive Validated Email Field inside preview */}
                <div className="space-y-1.5">
                  <label
                    htmlFor="workbench-sample-email"
                    className="block text-xs font-medium text-zinc-700"
                  >
                    Notification Recipient
                  </label>
                  <div className="flex flex-col sm:flex-row gap-2.5">
                    <input
                      id="workbench-sample-email"
                      type="email"
                      value={sampleEmail}
                      onChange={(e) => setSampleEmail(e.target.value)}
                      aria-invalid={!isSampleEmailValid}
                      className={`flex-1 px-3 py-2 text-sm bg-white border text-zinc-900 focus-visible:outline-none focus-visible:ring-2 ${
                        isSampleEmailValid
                          ? 'border-zinc-300 focus-visible:ring-[#1E40AF]'
                          : 'border-red-600 focus-visible:ring-red-600'
                      }`}
                      style={{ borderRadius: radius }}
                    />
                    <button
                      type="button"
                      onClick={() => setDisclosureOpen((prev) => !prev)}
                      aria-expanded={disclosureOpen}
                      className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold text-white transition-opacity hover:opacity-90 cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2"
                      style={{
                        backgroundColor: selectedAccent.hex,
                        borderRadius: radius,
                      }}
                    >
                      <span>{disclosureOpen ? 'Hide Audit Details' : 'Inspect Audit'}</span>
                      <ChevronDown
                        className={`w-3.5 h-3.5 transition-transform duration-150 ${
                          disclosureOpen ? 'rotate-180' : ''
                        }`}
                        aria-hidden="true"
                      />
                    </button>
                  </div>
                  {!isSampleEmailValid && (
                    <p className="text-xs text-red-700 font-medium">
                      Enter a valid email address format (e.g. name@company.com).
                    </p>
                  )}
                </div>

                {/* Accessible Disclosure Panel */}
                {disclosureOpen && (
                  <div
                    className="bg-[#FAFAFA] border border-zinc-200 p-4 text-xs text-zinc-700 space-y-2"
                    style={{ borderRadius: radius }}
                  >
                    <div className="flex items-center justify-between font-medium text-zinc-900">
                      <span>Keyboard &amp; Focus Order Check</span>
                      <span className="inline-flex items-center gap-1 font-mono text-zinc-700">
                        <Check className="w-3.5 h-3.5 text-emerald-700" aria-hidden="true" />
                        Passed
                      </span>
                    </div>
                    {previewScope === 'all' && (
                      <div className="flex items-center justify-between text-zinc-600">
                        <span>Zero Layout Shift Media Aspect Lock</span>
                        <span className="font-mono tabular-nums">CLS 0.000</span>
                      </div>
                    )}
                    <div className="flex items-center justify-between text-zinc-600">
                      <span>Contrast Ratio Verification</span>
                      <span className="font-mono tabular-nums">
                        {selectedAccent.contrast}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Bundle & Runtime Audit Grid */}
        {activeTab === 'audit' && (
          <div
            role="tabpanel"
            aria-label="Bundle and Runtime Grid"
            className="bg-[#FAFAFA] border border-zinc-200 rounded-xl p-6 space-y-5"
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="relative flex-1 max-w-sm">
                <Search
                  className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                  aria-hidden="true"
                />
                <input
                  type="search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Filter React modules..."
                  aria-label="Filter React modules"
                  className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-zinc-300 rounded-lg text-zinc-900 placeholder:text-zinc-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1E40AF]"
                />
              </div>

              <div className="flex flex-wrap items-center gap-4">
                <div
                  role="group"
                  aria-label="Module category filter"
                  className="inline-flex items-center gap-1 p-1 bg-zinc-200/70 rounded-lg"
                >
                  {(['All', 'Core', 'State', 'UI'] as CategoryFilter[]).map(
                    (cat) => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setCategoryFilter(cat)}
                        className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                          categoryFilter === cat
                            ? 'bg-white text-zinc-900 shadow-xs'
                            : 'text-zinc-600 hover:text-zinc-900'
                        }`}
                      >
                        {cat}
                      </button>
                    )
                  )}
                </div>

                <div className="text-xs text-zinc-600 font-mono tabular-nums whitespace-nowrap">
                  Visible total: <strong className="text-zinc-900">{totalBundleKb} KB</strong> gzip
                </div>
              </div>
            </div>

            {filteredModules.length === 0 ? (
              <div className="bg-white border border-zinc-200 rounded-lg p-10 text-center space-y-3">
                <p className="text-sm font-medium text-zinc-900">
                  No modules match &ldquo;{searchQuery}&rdquo; in {categoryFilter}.
                </p>
                <button
                  type="button"
                  onClick={resetAuditFilters}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-zinc-800 bg-zinc-100 hover:bg-zinc-200 rounded-lg transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Reset Filters</span>
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto bg-white border border-zinc-200 rounded-lg">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-zinc-200 text-xs font-semibold text-zinc-500">
                      <th className="py-3 px-4">Module</th>
                      <th className="py-3 px-4">Layer</th>
                      <th className="py-3 px-4">
                        <button
                          type="button"
                          onClick={() => handleSortToggle('gzipKb')}
                          className="inline-flex items-center gap-1 hover:text-zinc-900 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1E40AF] rounded-xs"
                        >
                          <span>Gzip Size</span>
                          <ArrowUpDown className="w-3.5 h-3.5" aria-hidden="true" />
                        </button>
                      </th>
                      <th className="py-3 px-4">
                        <button
                          type="button"
                          onClick={() => handleSortToggle('parseMs')}
                          className="inline-flex items-center gap-1 hover:text-zinc-900 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1E40AF] rounded-xs"
                        >
                          <span>Parse Time</span>
                          <ArrowUpDown className="w-3.5 h-3.5" aria-hidden="true" />
                        </button>
                      </th>
                      <th className="py-3 px-4">Tree-Shaken</th>
                      <th className="py-3 px-4">Audit State</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-200 text-sm">
                    {filteredModules.map((row: ModuleAuditRow) => (
                      <tr
                        key={row.id}
                        className="hover:bg-zinc-50/80 transition-colors"
                      >
                        <td className="py-3 px-4 font-mono text-xs font-medium text-zinc-900">
                          {row.moduleName}
                        </td>
                        <td className="py-3 px-4 text-xs text-zinc-600">
                          {row.category}
                        </td>
                        <td className="py-3 px-4 font-mono text-xs text-zinc-900 tabular-nums">
                          {row.gzipKb.toFixed(1)} KB
                        </td>
                        <td className="py-3 px-4 font-mono text-xs text-zinc-900 tabular-nums">
                          {row.parseMs.toFixed(1)} ms
                        </td>
                        <td className="py-3 px-4 font-mono text-xs text-zinc-700 tabular-nums">
                          {row.treeShaken}
                        </td>
                        <td className="py-3 px-4 text-xs font-medium">
                          <span
                            className={
                              row.status === 'Verified'
                                ? 'text-emerald-800'
                                : 'text-amber-800'
                            }
                          >
                            {row.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Motion & Frame Budget */}
        {activeTab === 'motion' && (
          <div
            role="tabpanel"
            aria-label="Motion and Frame Budget"
            className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch"
          >
            <div className="lg:col-span-5 bg-[#FAFAFA] border border-zinc-200 rounded-xl p-6 space-y-6">
              <div>
                <h3 className="text-sm font-semibold text-zinc-900 mb-3">
                  Easing Curve
                </h3>
                <div className="space-y-2">
                  {CURVE_OPTIONS.map((curve) => (
                    <button
                      key={curve.id}
                      type="button"
                      onClick={() => setSelectedCurveId(curve.id)}
                      className={`w-full text-left p-3 rounded-lg border transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1E40AF] ${
                        selectedCurveId === curve.id
                          ? 'bg-white border-zinc-900'
                          : 'bg-white/60 border-zinc-200 hover:bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-semibold text-zinc-900">
                          {curve.label}
                        </span>
                        <span className="font-mono text-[11px] text-zinc-500">
                          {curve.css}
                        </span>
                      </div>
                      <p className="text-xs text-zinc-600 mt-1">
                        {curve.description}
                      </p>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <label
                    htmlFor="motion-duration-range"
                    className="text-sm font-semibold text-zinc-900"
                  >
                    Settling Duration
                  </label>
                  <span className="font-mono text-xs font-semibold text-zinc-900 tabular-nums">
                    {durationMs} ms
                  </span>
                </div>
                <input
                  id="motion-duration-range"
                  type="range"
                  min={100}
                  max={280}
                  step={10}
                  value={durationMs}
                  onChange={(e) => setDurationMs(Number(e.target.value))}
                  className="w-full accent-[#1E40AF] cursor-pointer"
                />
                <div className="flex justify-between text-[11px] font-mono text-zinc-500 mt-1 tabular-nums">
                  <span>100 ms</span>
                  <span>200 ms routine ceiling</span>
                  <span>280 ms</span>
                </div>
              </div>
            </div>

            <div className="lg:col-span-7 bg-[#FAFAFA] border border-zinc-200 rounded-xl p-6 flex flex-col justify-between">
              <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-zinc-200">
                <div>
                  <h4 className="text-sm font-semibold text-zinc-900">
                    Compositor-Only Layer Preview
                  </h4>
                  <p className="text-xs text-zinc-500 mt-0.5">
                    Animates strictly <span className="font-mono">transform</span> and{' '}
                    <span className="font-mono">opacity</span> without layout reflow
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setPanelShifted((prev) => !prev)}
                  className="px-4 py-2 text-xs font-semibold text-white bg-[#1E40AF] hover:bg-[#1E3A8A] rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1E40AF] focus-visible:ring-offset-2"
                >
                  {panelShifted ? 'Reset Position' : 'Trigger Transition'}
                </button>
              </div>

              <div className="my-8 relative h-36 bg-white border border-zinc-200 rounded-lg overflow-hidden flex items-center px-6">
                <div
                  className="w-56 p-4 rounded-lg border border-zinc-200 bg-[#FAFAFA]"
                  style={{
                    transform: panelShifted
                      ? 'translate3d(140px, 0, 0)'
                      : 'translate3d(0, 0, 0)',
                    opacity: panelShifted ? 1 : 0.92,
                    transitionProperty: 'transform, opacity',
                    transitionDuration: `${durationMs}ms`,
                    transitionTimingFunction: selectedCurve.css,
                  }}
                >
                  <div className="text-xs font-semibold text-zinc-900">
                    Surface Layer
                  </div>
                  <div className="text-xs text-zinc-500 mt-1 font-mono tabular-nums">
                    {durationMs} ms · GPU composite
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-zinc-200 text-xs">
                <span className="text-zinc-600">
                  Budget Status:{' '}
                  <strong className="text-zinc-900">
                    {durationMs <= 200
                      ? 'Within 200 ms routine interaction budget'
                      : 'Suited for larger modal or drawer transitions'}
                  </strong>
                </span>
                <span className="font-mono text-zinc-500">
                  will-change: transform, opacity
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
