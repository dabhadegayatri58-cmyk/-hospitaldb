import { useRef, useState } from 'react';
import { TopNav } from './components/TopNav';
import { HeroSection } from './components/HeroSection';
import { InteractiveWorkbench } from './components/InteractiveWorkbench';
import { CapabilitiesSection } from './components/CapabilitiesSection';
import { CaseStudiesSection } from './components/CaseStudiesSection';
import { InquirySection } from './components/InquirySection';
import { Footer } from './components/Footer';

export default function App() {
  const inquiryNameRef = useRef<HTMLInputElement | null>(null);
  const [prefilledTopic, setPrefilledTopic] = useState('');

  const scrollToInquiry = (topic = '') => {
    if (topic) {
      setPrefilledTopic(topic);
    }
    const section = document.getElementById('inquiry');
    if (section) {
      section.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    window.setTimeout(() => {
      inquiryNameRef.current?.focus({ preventScroll: true });
    }, 350);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAFAFA] text-zinc-900">
      <TopNav onBookClick={() => scrollToInquiry()} />

      <main className="flex-1">
        <HeroSection onPrimaryCta={() => scrollToInquiry()} />
        <InteractiveWorkbench />
        <CapabilitiesSection />
        <CaseStudiesSection
          onRequestSimilar={(projectTitle) => scrollToInquiry(projectTitle)}
        />
        <InquirySection
          nameInputRef={inquiryNameRef}
          prefilledTopic={prefilledTopic}
        />
      </main>

      <Footer />
    </div>
  );
}
