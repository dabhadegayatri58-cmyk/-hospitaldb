import heroStudioImg from '../assets/images/hero_frontend_studio_1794633044409.jpg';
import fintechLedgerImg from '../assets/images/case_fintech_ledger_1794633044249.jpg';
import commerceSystemImg from '../assets/images/case_commerce_system_1794633045281.jpg';
import telemetryConsoleImg from '../assets/images/case_telemetry_console_1794633045132.jpg';

export const HERO_MEDIA = {
  src: heroStudioImg,
  alt: 'Minimalist front-end engineering studio with north-facing windows and an ash wood workstation displaying clean grid typography.',
};

export interface StudioMetric {
  value: string;
  label: string;
  context: string;
}

export const HERO_METRICS: StudioMetric[] = [
  {
    value: '18 ms',
    label: 'Median Interaction Latency',
    context: 'Measured across 14 production React apps',
  },
  {
    value: '99.9%',
    label: 'WCAG AA Audit Pass Rate',
    context: 'Automated & manual keyboard verification',
  },
  {
    value: '42',
    label: 'Shipped Web Front Ends',
    context: 'B2B SaaS, fintech, and industrial consoles',
  },
  {
    value: '1.1 s',
    label: 'Largest Contentful Paint',
    context: '75th percentile on 4G mobile profiles',
  },
];

export interface ModuleAuditRow {
  id: string;
  moduleName: string;
  category: 'Core' | 'State' | 'UI';
  gzipKb: number;
  parseMs: number;
  treeShaken: string;
  status: 'Verified' | 'Review';
}

export const MODULE_AUDIT_ROWS: ModuleAuditRow[] = [
  {
    id: 'react-dom-client',
    moduleName: 'react-dom/client',
    category: 'Core',
    gzipKb: 44.2,
    parseMs: 11.4,
    treeShaken: '98%',
    status: 'Verified',
  },
  {
    id: 'state-store',
    moduleName: 'kestrel/state-machine',
    category: 'State',
    gzipKb: 3.8,
    parseMs: 1.2,
    treeShaken: '100%',
    status: 'Verified',
  },
  {
    id: 'dialog-primitive',
    moduleName: 'kestrel/accessible-dialog',
    category: 'UI',
    gzipKb: 5.1,
    parseMs: 1.9,
    treeShaken: '96%',
    status: 'Verified',
  },
  {
    id: 'data-grid-core',
    moduleName: 'kestrel/virtual-grid',
    category: 'UI',
    gzipKb: 8.6,
    parseMs: 2.7,
    treeShaken: '94%',
    status: 'Verified',
  },
  {
    id: 'query-cache',
    moduleName: 'kestrel/query-sync',
    category: 'State',
    gzipKb: 11.4,
    parseMs: 3.5,
    treeShaken: '91%',
    status: 'Verified',
  },
  {
    id: 'route-loader',
    moduleName: 'kestrel/route-prefetch',
    category: 'Core',
    gzipKb: 6.2,
    parseMs: 2.1,
    treeShaken: '97%',
    status: 'Review',
  },
  {
    id: 'form-validator',
    moduleName: 'kestrel/schema-form',
    category: 'State',
    gzipKb: 4.9,
    parseMs: 1.6,
    treeShaken: '99%',
    status: 'Verified',
  },
];

export interface CapabilityItem {
  index: string;
  title: string;
  summary: string;
  outcome: string;
  span: 'wide' | 'standard';
}

export const CAPABILITIES: CapabilityItem[] = [
  {
    index: '01.',
    title: 'React Architecture & Predictable State',
    summary:
      'We structure complex client applications around explicit state transitions, URL-synchronized filters, and clean separation between server cache and ephemeral interface state.',
    outcome: 'Eliminates race conditions and redundant re-renders across high-frequency views.',
    span: 'wide',
  },
  {
    index: '02.',
    title: 'Accessible Component Systems',
    summary:
      'Tokenized TypeScript component libraries engineered for full keyboard navigation, screen reader announcements, and WCAG AA contrast compliance.',
    outcome: 'Shared primitives adopted cleanly across multi-team product surfaces.',
    span: 'standard',
  },
  {
    index: '03.',
    title: 'Bundle & Rendering Performance',
    summary:
      'Route-level code splitting, strict tree-shaking, zero layout-shift image frames, and compositor-only animations tuned to stay under 16ms frame budgets.',
    outcome: 'Sub-second interactive readiness without heavy runtime overhead.',
    span: 'standard',
  },
  {
    index: '04.',
    title: 'Data-Dense Workbenches & Forms',
    summary:
      'High-clarity financial tables, multi-step validated intake flows, and responsive keyboard-first consoles built with strict tabular alignment.',
    outcome: 'Higher task completion speed for daily operators and domain specialists.',
    span: 'wide',
  },
];

export interface CaseStudy {
  id: string;
  sector: string;
  stack: string;
  timeline: string;
  title: string;
  impactMetric: string;
  summary: string;
  image: string;
  imageAlt: string;
  challenge: string;
  architecture: string;
  results: string[];
}

export const CASE_STUDIES: CaseStudy[] = [
  {
    id: 'nordic-clearing',
    sector: 'Treasury & Clearing',
    stack: 'React 19 & TypeScript',
    timeline: 'Q3 2025',
    title: 'Multi-Currency Settlement Workbench for Nordic Clearing',
    impactMetric: '-62% Initial Bundle Size in 8 Weeks',
    summary:
      'Rebuilt a legacy settlement portal into a keyboard-navigable React workspace capable of filtering 25,000 live ledger entries without frame drops.',
    image: fintechLedgerImg,
    imageAlt: 'Brushed aluminum workstation monitor on a stone studio desk in natural daylight.',
    challenge:
      'Traders experienced 900ms UI freezes during market open due to unmemoized table trees and monolithic vendor bundles.',
    architecture:
      'Introduced route-split React chunks, window-virtualized tabular rows with strict tabular-nums alignment, and deterministic URL filter state.',
    results: [
      '-62% initial JavaScript payload (from 490 KB to 186 KB gzipped)',
      '14 ms median filter response time across 25,000 ledger rows',
      '100% WCAG AA keyboard audit pass across 38 settlement views',
    ],
  },
  {
    id: 'helvetia-hardware',
    sector: 'Industrial Retail',
    stack: 'React Design System',
    timeline: 'Q1 2026',
    title: 'Modular Hardware Configurator & Checkout System',
    impactMetric: '+38% Configurator Completion Rate',
    summary:
      'Engineered an interactive component library and live part-compatibility configurator for a European precision hardware manufacturer.',
    image: commerceSystemImg,
    imageAlt: 'Minimalist machined aluminum hardware components arranged on pale travertine stone.',
    challenge:
      'High drop-off on mobile and tablet browsers caused by slow step transitions and unclear validation errors during custom kit assembly.',
    architecture:
      'Built a deterministic state-machine wizard in React with inline schema validation, zero layout-shift asset frames, and instant price recalculation.',
    results: [
      '+38% configurator-to-cart completion within 90 days of launch',
      '0.00 Cumulative Layout Shift (CLS) across product media galleries',
      '28 reusable TypeScript primitives documented for internal engineers',
    ],
  },
  {
    id: 'vanguard-optics',
    sector: 'Optical Engineering',
    stack: 'React & Canvas Telemetry',
    timeline: 'Q2 2026',
    title: 'Laboratory Calibration Console & Audit Interface',
    impactMetric: '4.2x Faster Operator Calibration Workflow',
    summary:
      'Delivered a unified React front end connecting live optical bench readouts with structured pass/fail reporting and CSV export.',
    image: telemetryConsoleImg,
    imageAlt: 'Modern optical engineering laboratory bench with precision instruments and matte display.',
    challenge:
      'Lab technicians switched between three disconnected desktop utilities to verify lens tolerances and log calibration batches.',
    architecture:
      'Consolidated workflows into a single responsive React console with keyboard shortcuts, strict contrast discipline, and instant local draft recovery.',
    results: [
      '4.2x reduction in per-unit calibration logging time (from 11m to 2.6m)',
      'Zero lost inspection drafts during intermittent lab Wi-Fi drops',
      '1.1 s cold-start load time on ruggedized shop-floor tablets',
    ],
  },
];
